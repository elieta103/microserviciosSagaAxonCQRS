package com.appsdeveloperblog.estore.OrdersService.query;

import lombok.Value;

@Value
public class FindOrderQuery {

	private final String orderId;
	
}
