package com.appsdeveloperblog.estore.ProductsService.query;

public class FindProductsQuery {

}
